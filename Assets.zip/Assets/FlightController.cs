using UnityEngine;

public class FlightController : MonoBehaviour
{
    [Header("飛行設定")]
    public float forwardSpeed = 10f;  // 向前飛行的速度
    public float maneuverSpeed = 5f;  // 上下左右移動的速度

    [Header("音效設定")]
    public AudioClip flyingSound;     // 飛行音效 (Loop)
    public AudioClip crashSound;      // 撞擊音效
    public AudioClip passSound;       // 通過音效

    private AudioSource audioSource;
    private bool isCrashed = false;

    void Start()
    {
        // 獲取飛機上的 AudioSource 元件
        audioSource = GetComponent<AudioSource>();

        // 設定並播放持續的飛行音效
        if (flyingSound != null)
        {
            audioSource.clip = flyingSound;
            audioSource.loop = true;
            audioSource.Play();
        }
    }

    void Update()
    {
        // 如果已經撞毀，就不再執行移動
        if (isCrashed) return;

        // 1. 自動持續向前移動
        transform.Translate(Vector3.forward * forwardSpeed * Time.deltaTime);

        // 2. 獲取玩家鍵盤輸入 (WASD或方向鍵)
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        // 3. 根據輸入上下左右平移
        transform.Translate(new Vector3(horizontal, vertical, 0) * maneuverSpeed * Time.deltaTime);
    }

    // 處理實體碰撞 (撞到障礙物)
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Obstacle") && !isCrashed)
        {
            isCrashed = true;
            Debug.Log("撞到障礙物了！");

            // 停止引擎聲，播放撞擊聲
            audioSource.Stop();
            audioSource.PlayOneShot(crashSound);

            // 可以在這裡加入爆炸特效或顯示 Game Over 畫面
        }
    }

    // 處理觸發器穿透 (順利通過障礙物)
    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.CompareTag("PassZone") && !isCrashed)
        {
            Debug.Log("順利通過！加分！");

            // 播放通過音效 (不影響原本的引擎聲)
            audioSource.PlayOneShot(passSound);

            // 為了避免重複觸發，播放完後將該判定區銷毀或關閉
            other.gameObject.SetActive(false);
        }
    }
}